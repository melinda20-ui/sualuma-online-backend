"use client";

import { useEffect, useMemo, useState } from "react";

type Tab = "tudo" | "chats" | "agentes" | "automacoes";

type Thread = {
  id: string;
  title: string;
  agent_slug?: string;
  summary?: string;
  last_message?: string;
  messages_count?: number;
  created_at?: string;
  updated_at?: string;
};

type Message = {
  id: string;
  thread_id: string;
  role: "user" | "assistant" | "system";
  content: string;
  created_at?: string;
};

type Agent = {
  id: string;
  slug: string;
  name: string;
  subtitle?: string;
  badge?: string;
  is_active?: boolean;
};

type Automation = {
  id: string;
  slug: string;
  name: string;
  subtitle?: string;
  badge?: string;
  is_active?: boolean;
  status?: string;
};

type DashboardData = {
  ok: boolean;
  source?: string;
  selectedThreadId?: string;
  metrics?: {
    threads_total?: number;
    messages_total?: number;
    agents_active?: number;
    automations_active?: number;
  };
  threads?: Thread[];
  messages?: Message[];
  agents?: Agent[];
  automations?: Automation[];
  generated_at?: string;
  error?: string;
};

function timeAgo(date?: string) {
  if (!date) return "agora";
  const diff = Date.now() - new Date(date).getTime();
  const min = Math.floor(diff / 60000);
  if (min < 1) return "agora";
  if (min < 60) return `${min}min`;
  const h = Math.floor(min / 60);
  if (h < 24) return `${h}h`;
  const d = Math.floor(h / 24);
  return `${d}d`;
}

function Badge({ children, blue = false }: { children: React.ReactNode; blue?: boolean }) {
  return <span className={blue ? "badge blue" : "badge"}>{children}</span>;
}


function ChatAntigoBrainBridge() {
  const [message, setMessage] = useState("");
  const [answer, setAnswer] = useState("");
  const [loading, setLoading] = useState(false);
  const [online, setOnline] = useState(false);

  useEffect(() => {
    fetch("/api/chat-antigo/brain", { cache: "no-store" })
      .then((res) => res.json())
      .then((json) => setOnline(Boolean(json?.ok)))
      .catch(() => setOnline(false));
  }, []);

  async function sendToBrain() {
    const clean = message.trim();
    if (!clean || loading) return;

    setLoading(true);
    setAnswer("");

    try {
      const res = await fetch("/api/chat-antigo/brain", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        cache: "no-store",
        body: JSON.stringify({ message: clean }),
      });

      const json = await res.json();

      if (!json?.ok) {
        setAnswer(json?.error || "A Mia não conseguiu responder agora.");
        return;
      }

      setAnswer(json.answer || "A Mia respondeu, mas não veio texto.");
      setMessage("");
      setOnline(true);
    } catch (error) {
      setAnswer("Erro ao falar com o cérebro da Mia.");
      setOnline(false);
    } finally {
      setLoading(false);
    }
  }

  return (
    <section
      style={{
        marginTop: 18,
        padding: 18,
        borderRadius: 22,
        border: "1px solid rgba(255,255,255,.12)",
        background:
          "radial-gradient(circle at top left, rgba(255,0,120,.16), transparent 34%), rgba(10,10,18,.72)",
        boxShadow: "0 20px 60px rgba(0,0,0,.28)",
      }}
    >
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: 12, marginBottom: 12 }}>
        <div>
          <p style={{ margin: 0, color: "rgba(255,255,255,.58)", fontSize: 12, letterSpacing: ".12em", textTransform: "uppercase" }}>
            Cérebro Mia
          </p>
          <h3 style={{ margin: "4px 0 0", color: "#fff", fontSize: 20 }}>
            Ponte viva com o cérebro da plataforma
          </h3>
        </div>

        <span
          style={{
            padding: "8px 12px",
            borderRadius: 999,
            background: online ? "rgba(34,197,94,.14)" : "rgba(251,191,36,.14)",
            color: online ? "#86efac" : "#fde68a",
            border: online ? "1px solid rgba(34,197,94,.28)" : "1px solid rgba(251,191,36,.28)",
            fontSize: 12,
            whiteSpace: "nowrap",
          }}
        >
          {online ? "Online" : "Conectando"}
        </span>
      </div>

      <textarea
        value={message}
        onChange={(event) => setMessage(event.target.value)}
        placeholder="Digite uma ordem para a Mia: resumir conversa, criar automação, analisar cliente, puxar contexto..."
        style={{
          width: "100%",
          minHeight: 96,
          resize: "vertical",
          borderRadius: 18,
          border: "1px solid rgba(255,255,255,.12)",
          background: "rgba(0,0,0,.24)",
          color: "#fff",
          padding: 14,
          outline: "none",
        }}
      />

      <div style={{ display: "flex", gap: 10, flexWrap: "wrap", marginTop: 12 }}>
        <button
          type="button"
          onClick={sendToBrain}
          disabled={loading}
          style={{
            border: 0,
            borderRadius: 999,
            padding: "12px 18px",
            cursor: loading ? "not-allowed" : "pointer",
            color: "#fff",
            fontWeight: 800,
            background: "linear-gradient(135deg, #ff2f8f, #7c3aed)",
            boxShadow: "0 12px 34px rgba(255,47,143,.28)",
          }}
        >
          {loading ? "Pensando..." : "Enviar para o cérebro"}
        </button>

        <button
          type="button"
          onClick={() => setMessage("Analise o estado atual do meu sistema e me diga o próximo passo mais importante.")}
          style={{
            borderRadius: 999,
            padding: "12px 18px",
            cursor: "pointer",
            color: "#fff",
            background: "rgba(255,255,255,.08)",
            border: "1px solid rgba(255,255,255,.12)",
          }}
        >
          Diagnóstico rápido
        </button>
      </div>

      {answer ? (
        <div
          style={{
            marginTop: 14,
            padding: 14,
            borderRadius: 18,
            background: "rgba(255,255,255,.07)",
            border: "1px solid rgba(255,255,255,.10)",
            color: "rgba(255,255,255,.86)",
            whiteSpace: "pre-wrap",
            lineHeight: 1.55,
          }}
        >
          {answer}
        </div>
      ) : null}
    </section>
  );
}


export default function ChatAntigoPage() {
  const [tab, setTab] = useState<Tab>("tudo");
  const [data, setData] = useState<DashboardData | null>(null);
  const [selectedThreadId, setSelectedThreadId] = useState("");

  useEffect(() => {
    let mounted = true;

    async function loadChatAntigoDb() {
      try {
        const res = await fetch("/api/chat-antigo", {
          cache: "no-store",
        });

        const json = await res.json();

        if (!mounted || !json?.ok) return;

        setData((prev: any) => ({
          ...(prev || {}),
          ...json,
          threads: json.conversations || prev?.threads || [],
          conversas: json.conversations || prev?.conversas || [],
          conversations: json.conversations || prev?.conversations || [],
          messages: json.messages || prev?.messages || [],
          mensagens: json.messages || prev?.mensagens || [],
          agents: json.agents || prev?.agents || [],
          agentes: json.agents || prev?.agentes || [],
          automations: json.automations || prev?.automations || [],
          automacoes: json.automations || prev?.automacoes || [],
          mia: json.mia || prev?.mia || {},
          metrics: json.metrics || prev?.metrics || {},
          metricas: json.metrics || prev?.metricas || {},
          source: json.source || "postgres-direct",
          generated_at: json.generated_at,
        }));

        const firstThread =
          json.conversations?.[0]?.id ||
          json.conversations?.[0]?.thread_id ||
          json.conversations?.[0]?.conversation_id ||
          "";

        if (firstThread) {
          setSelectedThreadId((current: string) => current || String(firstThread));
        }
      } catch (error) {
        console.error("Erro ao carregar /api/chat-antigo:", error);
      }
    }

    loadChatAntigoDb();
    const timer = setInterval(loadChatAntigoDb, 30000);

    return () => {
      mounted = false;
      clearInterval(timer);
    };
  }, []);

  const [message, setMessage] = useState("");
  const [loading, setLoading] = useState(true);
  const [sending, setSending] = useState(false);

  const threads = (data?.threads || []).filter((thread: Thread) => {
    const title = String(thread?.title || "").trim().toLowerCase();
    return ![
      "atendimento clientes",
      "campanha de e-mail",
      "planejamento 12 semanas",
    ].includes(title);
  });
  const messages = (data?.messages || []).filter((msg: Message) => {
    const content = String(msg?.content || "");
    return !(
      content.includes("No próximo passo") ||
      content.includes("roteador de IA") ||
      content.includes("Recebi sua mensagem e salvei esta conversa") ||
      content.includes("vou conectar essa conversa")
    );
  });
  const agents: Agent[] = []; // MODO VERDADE: não mostrar agentes inventados/mockados
  const automations: Automation[] = []; // MODO VERDADE: não mostrar automações inventadas/mockadas

  const selectedThread = threads.find((thread) => thread.id === selectedThreadId) || threads[0];

  const currentTitle = useMemo(() => {
    return selectedThread?.title ? `Mia — ${selectedThread.title}` : "Mia — Novo chat";
  }, [selectedThread]);

  async function load(threadId?: string) {
    try {
      setLoading(true);
      const url = threadId
        ? `/api/studio/chat-dashboard?threadId=${encodeURIComponent(threadId)}`
        : "/api/studio/chat-dashboard";

      const res = await fetch(url, { cache: "no-store" });
      const json = await res.json();

      setData(json);

      if (!selectedThreadId && json?.selectedThreadId) {
        setSelectedThreadId(json.selectedThreadId);
      }
    } catch (error) {
      setData({ ok: false, error: "Falha ao carregar chat." });
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    const currentThreadId = selectedThreadId || undefined;

    load(currentThreadId);

    const timer = window.setInterval(() => {
      load(currentThreadId);
    }, 30000);

    return () => window.clearInterval(timer);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedThreadId]);

  async function selectThread(threadId: string) {
    setSelectedThreadId(threadId);
    await load(threadId);
  }

  async function createThread() {
    const title = prompt("Nome do novo chat:", "Novo chat");
    if (!title) return;

    const res = await fetch("/api/studio/chat-dashboard", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "create-thread", title }),
    });

    const json = await res.json();

    if (json?.ok && json?.thread?.id) {
      const newThreadId = json.thread.id;

      setSelectedThreadId(newThreadId);
      setMessage("");

      setData((prev: any) => ({
        ...(prev || {}),
        selectedThreadId: newThreadId,
        threads: [
          json.thread,
          ...((prev?.threads || []).filter((thread: Thread) => thread.id !== newThreadId)),
        ],
        messages: [],
      }));

      await load(newThreadId);
    } else {
      alert(json?.error || "Não consegui criar o chat.");
    }
  }

  async function sendMessage() {
    if (!message.trim() || !selectedThreadId || sending) return;

    const content = message.trim();
    setMessage("");
    setSending(true);

    try {
      const res = await fetch("/api/studio/chat-dashboard", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          action: "send-message",
          thread_id: selectedThreadId,
          content,
        }),
      });

      const json = await res.json();

      if (!json?.ok) {
        alert(json?.error || "Não consegui enviar a mensagem.");
      }

      await load(selectedThreadId);
    } finally {
      setSending(false);
    }
  }

  async function toggleAutomation(auto: Automation) {
    await fetch("/api/studio/chat-dashboard", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        action: "toggle-automation",
        slug: auto.slug,
        is_active: !auto.is_active,
      }),
    });

    await load(selectedThreadId);
  }

  const visibleChats = tab === "tudo" || tab === "chats";
  const visibleAgents = tab === "tudo" || tab === "agentes";
  const visibleAutomations = tab === "tudo" || tab === "automacoes";

  return (
    <main className="chat-shell">
      <aside className="sidebar">
        <div className="brand">
          <div className="brand-icon">S</div>
          <div>
            <strong>sualuma</strong>
            <span>Seu universo de IA</span>
          </div>
          <button className="collapse">‹</button>
        </div>

        <button className="new-chat" onClick={createThread}>
          <span>＋</span>
          Novo chat
          <small>DB</small>
        </button>

        <div className="tabs">
          <button onClick={() => setTab("tudo")} className={tab === "tudo" ? "active" : ""}>Tudo</button>
          <button onClick={() => setTab("chats")} className={tab === "chats" ? "active" : ""}>Chats</button>
          <button onClick={() => setTab("agentes")} className={tab === "agentes" ? "active" : ""}>Agentes</button>
          <button onClick={() => setTab("automacoes")} className={tab === "automacoes" ? "active" : ""}>Automações</button>
        </div>

        <div className="sidebar-scroll">
          {visibleChats && (
            <section className="side-section">
              <div className="section-head">
                <span>Conversas</span>
                <button>{loading ? "..." : "⌃"}</button>
              </div>

              {threads.map((thread) => (
                <button
                  key={thread.id}
                  className={selectedThreadId === thread.id ? "side-item selected" : "side-item"}
                  onClick={() => selectThread(thread.id)}
                >
                  <span className="mini-icon">☰</span>
                  <strong>{thread.title}</strong>
                  <em>{timeAgo(thread.updated_at)}</em>
                </button>
              ))}

              {threads.length === 0 && <p className="empty">Nenhum chat ainda.</p>}
            </section>
          )}

          {visibleAgents && (
            <section className="side-section">
              <div className="section-head">
                <span>Agentes</span>
                <button>＋</button>
              </div>

              {agents.map((agent) => (
                <button key={agent.id} className="agent-item">
                  <span className="avatar">{agent.name.slice(0, 1)}</span>
                  <span>
                    <strong>{agent.name}</strong>
                    <small>{agent.subtitle || "Agente conectado"}</small>
                  </span>
                  <Badge blue={agent.badge === "Em breve"}>{agent.badge || "Em breve"}</Badge>
                  {agent.is_active && <i />}
                </button>
              ))}
            </section>
          )}

          {visibleAutomations && (
            <section className="side-section">
              <div className="section-head">
                <span>Automações</span>
                <button>＋</button>
              </div>

              {automations.map((auto) => (
                <button key={auto.id} className="agent-item" onClick={() => toggleAutomation(auto)}>
                  <span className="auto-icon">✦</span>
                  <span>
                    <strong>{auto.name}</strong>
                    <small>{auto.subtitle || "Automação conectada"}</small>
                  </span>
                  <Badge blue={auto.badge === "Criada"}>{auto.badge || "Criada"}</Badge>
                  {auto.is_active && <i />}
                </button>
              ))}
            </section>
          )}
        </div>

        <div className="profile">
          <div className="profile-photo">L</div>
          <div>
            <strong>Luma Studio</strong>
            <span>{data?.ok ? "Banco online" : "Banco offline"}</span>
          </div>
          <button>⋮</button>
        </div>
      </aside>

      <section className="main-chat">
        <header className="topbar">
          <div className="conversation-title">
            <div className="robot">◎</div>
            <h1>{currentTitle}</h1>
            <span>⌄</span>
          </div>

          <div className="top-actions">
            <button onClick={() => load(selectedThreadId)}>↻ Atualizar</button>
            <button>📎</button>
            <button>🎙</button>
            <button>⚙ Configurações</button>
          </div>
        </header>

        <div className="chat-body">
          <div className="messages">
            {messages.length === 0 && (
              <div className="welcome">
                <h2>💬 Chat conectado ao banco</h2>
                <p>Crie conversas, envie mensagens e acompanhe tudo salvo no PostgreSQL/Supabase.</p>
              </div>
            )}

            {messages.map((msg) =>
              msg.role === "user" ? (
                <div className="user-bubble" key={msg.id}>
                  <p>{msg.content}</p>
                  <span>{timeAgo(msg.created_at)} ✓✓</span>
                </div>
              ) : (
                <div className="assistant-row" key={msg.id}>
                  <div className="bot-avatar">🤖</div>
                  <div className="assistant-bubble">
                    <p className="intro">{msg.content}</p>
                    <div className="message-actions">
                      <button>⧉</button>
                      <button>👍</button>
                      <button>👎</button>
                      <button>🔖</button>
                      <span>{timeAgo(msg.created_at)}</span>
                    </div>
                  </div>
                </div>
              )
            )}
          </div>

          <aside className="context-panel">
            <div className="context-card">
              <h3>Modo verdade</h3>
              <div className="quick-list">
                <p><span>Fonte</span><b>{data?.source || "postgres"}</b></p>
                <p><span>Conversas</span><b>{data?.metrics?.threads_total || 0}</b></p>
                <p><span>Mensagens</span><b>{data?.metrics?.messages_total || 0}</b></p>
                <p><span>Agentes ativos</span><b>{agents.length}</b></p>
                <p><span>Automações ativas</span><b>{automations.length}</b></p>
              </div>
            </div>

            <div className="context-card">
              <h3>Sobre este agente</h3>
              <div className="agent-feature">
                <div className="big-avatar">🤖</div>
                <div>
                  <strong>Mia <Badge>Ativa</Badge></strong>
                  <p>Sua assistente inteligente para estratégia, planejamento e tomada de decisão.</p>
                </div>
              </div>
              <button className="outline-btn">Ver detalhes do agente ↗</button>
            </div>

            <div className="context-card">
              <div className="card-head">
                <h3>Automações reais</h3>
                <button>Gerenciar</button>
              </div>

              {automations.slice(0, 4).map((auto) => (
                <div className="toggle-line" key={auto.id} onClick={() => toggleAutomation(auto)}>
                  <span>{auto.name}</span>
                  <b>{auto.is_active ? "Ativa" : "Pausada"}</b>
                  <i className={auto.is_active ? "on" : ""} />
                </div>
              ))}
            </div>

            <div className="pro-card">
              <h3>💎 Status real</h3>
              <p>Chat conectado ao Cérebro Blue real. As respostas passam pelo cérebro operacional da Sualuma e o histórico fica registrado no banco.</p>
              <button>Cérebro Blue ativo</button>
            </div>
          </aside>
        </div>

        <div className="composer">
          <div className="input-wrap">
            <textarea
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="Mensagem para a Mia..."
              onKeyDown={(e) => {
                if (e.key === "Enter" && !e.shiftKey) {
                  e.preventDefault();
                  sendMessage();
                }
              }}
            />
            <div className="composer-actions">
              <button>📎 Anexar</button>
              <button>🎙 Falar</button>
            </div>
            <button className="send" onClick={sendMessage} disabled={sending}>
              {sending ? "..." : "➤"}
            </button>
          </div>

          <p>{data?.ok ? "Conectado ao banco vivo." : data?.error || "Carregando banco..."}</p>
        </div>
      </section>

      <style jsx global>{`
        *{box-sizing:border-box}
        body{margin:0;background:#030712;color:#f8fafc;font-family:Inter,ui-sans-serif,system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif}
        button,textarea{font:inherit}
        .chat-shell{min-height:100vh;display:grid;grid-template-columns:340px 1fr;background:radial-gradient(circle at 20% 0%,rgba(59,130,246,.2),transparent 32%),radial-gradient(circle at 70% 100%,rgba(147,51,234,.18),transparent 34%),linear-gradient(135deg,#020617,#050816 55%,#020617);padding:14px;gap:14px}
        .sidebar,.main-chat{border:1px solid rgba(148,163,184,.22);background:rgba(3,7,18,.76);box-shadow:0 24px 80px rgba(0,0,0,.45),inset 0 1px 0 rgba(255,255,255,.05);backdrop-filter:blur(18px);border-radius:22px;overflow:hidden}
        .sidebar{display:flex;flex-direction:column;padding:14px}
        .brand{display:flex;align-items:center;gap:12px;padding:4px 4px 12px}
        .brand-icon{width:44px;height:44px;display:grid;place-items:center;border-radius:14px;background:linear-gradient(135deg,rgba(34,211,238,.25),rgba(124,58,237,.25));color:#67e8f9;font-size:24px;font-weight:900;box-shadow:0 0 28px rgba(34,211,238,.35)}
        .brand strong{display:block;font-size:24px;letter-spacing:-.04em}.brand span{color:#94a3b8;font-size:12px}
        .collapse{margin-left:auto;width:30px;height:30px;border:1px solid rgba(148,163,184,.24);background:rgba(15,23,42,.65);color:white;border-radius:10px}
        .new-chat{height:56px;border:0;color:white;border-radius:12px;background:linear-gradient(135deg,#7c3aed,#2563eb);box-shadow:0 0 28px rgba(37,99,235,.35);display:flex;align-items:center;justify-content:center;gap:10px;font-weight:800;cursor:pointer}
        .new-chat span{font-size:24px}.new-chat small{margin-left:auto;margin-right:12px;color:rgba(255,255,255,.7)}
        .tabs{margin-top:12px;display:grid;grid-template-columns:repeat(4,1fr);gap:4px;padding:4px;background:rgba(15,23,42,.8);border:1px solid rgba(148,163,184,.14);border-radius:12px}
        .tabs button{border:0;background:transparent;color:#94a3b8;border-radius:9px;padding:8px 4px;cursor:pointer;font-size:12px}.tabs button.active{background:linear-gradient(135deg,rgba(124,58,237,.55),rgba(37,99,235,.35));color:white;box-shadow:inset 0 0 0 1px rgba(255,255,255,.08)}
        .sidebar-scroll{flex:1;overflow:auto;padding-right:2px}.side-section{padding-top:14px;border-bottom:1px solid rgba(148,163,184,.14);padding-bottom:10px}
        .section-head{display:flex;justify-content:space-between;align-items:center;color:#94a3b8;font-size:12px;text-transform:uppercase;letter-spacing:.06em;margin:0 8px 8px}.section-head button{background:transparent;color:#94a3b8;border:0}
        .side-item,.agent-item{width:100%;min-height:36px;display:flex;align-items:center;gap:9px;border:0;background:transparent;color:#e5e7eb;border-radius:10px;padding:8px;cursor:pointer;text-align:left}
        .side-item:hover,.agent-item:hover{background:rgba(59,130,246,.08)}.side-item.selected{background:linear-gradient(135deg,rgba(124,58,237,.35),rgba(37,99,235,.18));outline:1px solid rgba(124,58,237,.75);box-shadow:0 0 20px rgba(124,58,237,.18)}
        .side-item strong{font-size:13px;flex:1}.side-item em{color:#94a3b8;font-size:11px;font-style:normal}.mini-icon{width:20px;color:#c4b5fd}
        .agent-item .avatar,.auto-icon{width:32px;height:32px;flex:0 0 32px;border-radius:10px;display:grid;place-items:center;background:linear-gradient(135deg,rgba(124,58,237,.55),rgba(34,211,238,.22));box-shadow:0 0 18px rgba(124,58,237,.22)}
        .auto-icon{background:linear-gradient(135deg,rgba(37,99,235,.65),rgba(16,185,129,.2))}
        .agent-item span:nth-child(2){min-width:0;flex:1}.agent-item strong{display:block;font-size:13px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.agent-item small{display:block;color:#94a3b8;font-size:11px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
        .badge{border:1px solid rgba(168,85,247,.5);background:rgba(124,58,237,.18);color:#c4b5fd;border-radius:999px;padding:4px 8px;font-size:10px;font-weight:700;white-space:nowrap}.badge.blue{border-color:rgba(59,130,246,.5);background:rgba(37,99,235,.18);color:#93c5fd}
        .agent-item i{width:7px;height:7px;border-radius:50%;background:#22c55e;box-shadow:0 0 10px rgba(34,197,94,.85)}
        .empty{color:#64748b;font-size:12px;padding:8px}
        .profile{margin-top:12px;border:1px solid rgba(148,163,184,.18);background:rgba(15,23,42,.55);border-radius:14px;padding:10px;display:flex;align-items:center;gap:10px}
        .profile-photo{width:38px;height:38px;border-radius:50%;display:grid;place-items:center;background:linear-gradient(135deg,#f472b6,#60a5fa);font-weight:900}.profile strong{display:block;font-size:13px}.profile span{color:#94a3b8;font-size:11px}.profile button{margin-left:auto;border:0;background:transparent;color:#94a3b8;font-size:20px}
        .main-chat{display:flex;flex-direction:column}.topbar{height:58px;padding:0 22px;display:flex;align-items:center;justify-content:space-between;border-bottom:1px solid rgba(148,163,184,.14);background:rgba(2,6,23,.64)}
        .conversation-title{display:flex;align-items:center;gap:12px}.conversation-title h1{font-size:18px;margin:0;letter-spacing:-.03em}.robot{width:34px;height:34px;border-radius:50%;display:grid;place-items:center;background:radial-gradient(circle,rgba(34,211,238,.45),rgba(124,58,237,.25));box-shadow:0 0 24px rgba(124,58,237,.45)}
        .top-actions{display:flex;gap:8px}.top-actions button{height:38px;border-radius:10px;border:1px solid rgba(148,163,184,.22);background:rgba(15,23,42,.62);color:#e5e7eb;padding:0 12px;cursor:pointer}
        .chat-body{flex:1;display:grid;grid-template-columns:minmax(0,1fr) 310px;gap:18px;padding:20px 26px 0;overflow:hidden}.messages{overflow:auto;padding:0 10px 18px 0}
        .welcome{border:1px solid rgba(148,163,184,.2);background:rgba(15,23,42,.72);border-radius:18px;padding:20px;color:#cbd5e1}.welcome h2{margin:0 0 8px;color:white}
        .user-bubble{width:min(520px,82%);margin:0 0 20px auto;border:1px solid rgba(124,58,237,.65);background:linear-gradient(135deg,rgba(88,28,135,.55),rgba(30,41,59,.72));padding:14px 16px;border-radius:18px;box-shadow:0 0 32px rgba(124,58,237,.18)}.user-bubble p{margin:0 0 8px;line-height:1.5}.user-bubble span{display:block;text-align:right;color:#93c5fd;font-size:12px}
        .assistant-row{margin:0 0 24px;display:flex;gap:14px;align-items:flex-start}.bot-avatar{width:54px;height:54px;border-radius:50%;display:grid;place-items:center;background:radial-gradient(circle,rgba(34,211,238,.45),rgba(124,58,237,.2));border:1px solid rgba(96,165,250,.5);box-shadow:0 0 28px rgba(59,130,246,.35)}
        .assistant-bubble{width:min(620px,100%);border:1px solid rgba(148,163,184,.2);background:rgba(15,23,42,.72);border-radius:18px;padding:16px;box-shadow:0 22px 60px rgba(0,0,0,.35)}.intro{margin:0;color:#e5e7eb;line-height:1.55}
        .message-actions{display:flex;align-items:center;gap:8px;margin-top:12px}.message-actions button{border:0;background:transparent;color:#94a3b8;cursor:pointer}.message-actions span{margin-left:auto;color:#94a3b8;font-size:12px}
        .context-panel{overflow:auto;padding-bottom:18px}.context-card,.pro-card{border:1px solid rgba(148,163,184,.2);background:rgba(15,23,42,.68);border-radius:16px;padding:16px;margin-bottom:14px}.context-card h3,.pro-card h3{margin:0 0 14px;font-size:14px}
        .agent-feature{display:flex;gap:12px;align-items:center;border-top:1px solid rgba(148,163,184,.12);padding-top:14px}.big-avatar{width:54px;height:54px;border-radius:50%;display:grid;place-items:center;background:radial-gradient(circle,rgba(96,165,250,.42),rgba(124,58,237,.24))}.agent-feature p{color:#94a3b8;font-size:12px;line-height:1.4;margin:6px 0 0}
        .outline-btn{width:100%;height:38px;margin-top:14px;border:1px solid rgba(148,163,184,.22);background:rgba(2,6,23,.35);color:#c4b5fd;border-radius:10px;cursor:pointer}
        .quick-list{display:grid;gap:12px}.quick-list p{margin:0;display:flex;justify-content:space-between;gap:10px;color:#94a3b8;font-size:12px}.quick-list b{color:#e5e7eb;font-weight:600;text-align:right}
        .card-head{display:flex;justify-content:space-between;align-items:center}.card-head button{border:0;background:transparent;color:#c084fc;cursor:pointer;font-size:12px}
        .toggle-line{display:flex;align-items:center;gap:8px;padding:9px 0;color:#e5e7eb;font-size:13px;cursor:pointer}.toggle-line span{flex:1}.toggle-line b{color:#94a3b8;font-size:11px;font-weight:500}.toggle-line i{width:30px;height:17px;border-radius:999px;background:#334155;position:relative}.toggle-line i:after{content:"";position:absolute;width:13px;height:13px;left:2px;top:2px;border-radius:50%;background:#94a3b8}.toggle-line i.on{background:#2563eb}.toggle-line i.on:after{left:15px;background:white}
        .pro-card{background:radial-gradient(circle at 90% 40%,rgba(59,130,246,.35),transparent 28%),linear-gradient(135deg,rgba(88,28,135,.7),rgba(15,23,42,.85));border-color:rgba(124,58,237,.7);box-shadow:0 0 32px rgba(124,58,237,.18)}.pro-card p{color:#cbd5e1;font-size:13px;line-height:1.45}.pro-card button{border:1px solid rgba(196,181,253,.45);background:rgba(124,58,237,.32);color:white;border-radius:10px;padding:10px 14px;cursor:pointer}
        .composer{padding:14px 26px 10px}.input-wrap{min-height:86px;border:1px solid rgba(96,165,250,.7);border-radius:24px;background:rgba(15,23,42,.82);box-shadow:0 0 38px rgba(37,99,235,.18),0 0 34px rgba(124,58,237,.18);display:grid;grid-template-columns:1fr auto;grid-template-rows:1fr auto;gap:8px;padding:14px}.input-wrap textarea{grid-column:1;border:0;outline:none;resize:none;color:white;min-height:34px;background:transparent}.input-wrap textarea::placeholder{color:#64748b}.composer-actions{display:flex;gap:8px}.composer-actions button{border:1px solid rgba(148,163,184,.22);background:rgba(2,6,23,.35);color:#e5e7eb;border-radius:10px;padding:8px 12px;cursor:pointer}.send{grid-column:2;grid-row:1/3;width:54px;height:54px;border-radius:50%;border:0;align-self:center;background:linear-gradient(135deg,#7c3aed,#2563eb);color:white;font-size:22px;cursor:pointer;box-shadow:0 0 28px rgba(37,99,235,.5)}.send:disabled{opacity:.6;cursor:not-allowed}.composer p{margin:6px 0 0;text-align:center;color:#64748b;font-size:11px}
        @media(max-width:1180px){.chat-shell{grid-template-columns:300px 1fr}.chat-body{grid-template-columns:1fr}.context-panel{display:none}}
        @media(max-width:820px){.chat-shell{grid-template-columns:1fr;padding:8px}.sidebar{max-height:48vh}.topbar{height:auto;padding:14px;align-items:flex-start;gap:12px;flex-direction:column}.top-actions{flex-wrap:wrap}.chat-body{padding:14px}.composer{padding:10px 14px}}
      `}</style>
          {false && <ChatAntigoBrainBridge />}
    </main>
  );
}
